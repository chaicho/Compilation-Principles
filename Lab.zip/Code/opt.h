#ifdef __OPT__
#define __OPT__
extern struct InterCode_;
void OptIr(struct InterCode_  * codelist);


#endif